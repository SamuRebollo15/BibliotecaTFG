﻿using System.ComponentModel.DataAnnotations;

namespace Biblioteca.Models
{
    public class Book
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; }

        [Required]
        [StringLength(100)]
        public string Author { get; set; }

        [Required]
        public string Genre { get; set; }

        [Required]
        [Range(0, 10000)]
        public int Copies { get; set; }
    }
}
